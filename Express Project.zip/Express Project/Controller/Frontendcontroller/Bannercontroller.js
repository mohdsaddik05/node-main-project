const  bannerdb = require('../../models/admin/bannerdb')
const  addressdb = require('../../models/admin/addressdb')
const  companydb = require('../../models/admin/companydb')
let sess= null;

exports.bannershow= async (req, res) => {
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    const record = await bannerdb.findOne()
    if (sess !== null) {
    res.render('moredetail.ejs', { record, addressview, companyview, username: sess.username})
    }else{
      res.render('moredetail.ejs', { record, addressview, companyview, username: 'hello'})
  
    }
  }
  