const servicesdb = require('../../models/admin/servicedb')

exports.servicesshow=async (req, res) => {
    const record = await servicesdb.find().sort({ postedDate: -1 })
    const totalrecord = await servicesdb.count()
    const totalpublish = await servicesdb.count({ status: 'publish' })
    const totalunpublish = await servicesdb.count({ status: 'unpublish' })
    //console.log(totalunpublish)
    res.render('admin/service.ejs', { record, totalrecord, totalpublish, totalunpublish })
}

exports.servicesadd=  (req, res) => {
    res.render('admin/serviceform.ejs')
}

exports.servicesinsert= async (req, res) => {
    const todayDate = Date()
    const { title, desc, ldesc } = req.body
    if (req.file) {
        const imgname = req.file.filename
        const record = new servicesdb({ img: imgname, title: title, desc: desc, ldesc: ldesc, status: 'unpublish', postedDate: todayDate })
        await record.save()
        //console.log(record)
    } else {
        const record = new servicesdb({ title: title, desc: desc, ldesc: ldesc, status: 'unpublish', postedDate: todayDate })
    }
    res.redirect('/admin/service')
}

exports.servicesdelete= async (req, res) => {
    const id = req.params.abc
    await servicesdb.findByIdAndDelete(id)
    res.redirect('/admin/service')
}

exports.servicesupdate= async (req, res) => {
    const id = req.params.xyz
    const record = await servicesdb.findById(id)
    // console.log(record)

    let newStatus = null

    if (record.status == 'unpublish') {
        newStatus = 'publish'
    } else {
        newStatus = 'unpublish'
    }
    await servicesdb.findByIdAndUpdate(id, { status: newStatus })
    res.redirect('/admin/service')

}

