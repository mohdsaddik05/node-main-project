const  addressdb = require('../../models/admin/addressdb')


exports.addressshow= async (req, res) => {
    const record = await addressdb.find()
    res.render('admin/address.ejs', { record })
}

exports.addressinsertshow=  (req, res) => {
    res.render('admin/addressinsert.ejs')
}

exports.addressinsert= async (req, res) => {
    const { address, mobile, tele } = req.body
    const record = new addressdb({ address: address, mobile: mobile, telephone: tele })
    await record.save()
    console.log(record)
    res.redirect('/admin/address')
}

exports.addressupdateshow= async (req, res) => {
    const id = req.params.id
    const record = await addressdb.findById(id)
    res.render('admin/addressupdate.ejs', { record })
}

exports.addressupdate=  async (req, res) => {

    const id = req.params.id
    const { address, mobile, tele } = req.body
    await addressdb.findByIdAndUpdate(id, { address: address, mobile: mobile, telephone: tele })
    res.redirect('/admin/address')
}

exports.addressdelete= async(req,res)=>{

    const id= req.params.id
    const record = await addressdb.findByIdAndDelete(id)
    res.redirect('/admin/address')
}