const querydb = require('../../models/admin/querydb')
const nodemailer = require('nodemailer')

exports.queryshow= async (req, res) => {
    const record = await querydb.find().sort({ postedDate: -1 })
    res.render('admin/query.ejs', { record })
}

exports.querypost=  async (req, res) => {
    const { email, query } = req.body
    const record = new querydb({ email: email, query: query, status: 'unread', postedDate: new Date() })
    await record.save()
    res.redirect('/')

}

exports.replyshow= async (req, res) => {
    const id = req.params.id
    const record = await querydb.findById(id)
    res.render('admin/replyform.ejs', { id, record })
}

exports.replysend=  async (req, res) => {
    const id = req.params.id
    const record = await querydb.findById(id)

    const filepath = req.file.path

    const { sub, body } = req.body

    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: 'vkexpress0@gmail.com', // generated ethereal user
            pass: 'dycujchkexljgrft', // generated ethereal password
        },
    });

    let info = await transporter.sendMail({
        from: 'vkexpress0@gmail.com', // sender address
        to: record.email, // list of receivers
        subject: sub, // Subject line
        text: body, // plain text body
        attachments: [
            { path: filepath }
        ]
        // html: "<b>Hello world?</b>", // html body
    });

    await querydb.findByIdAndUpdate(id, { status: 'read' })
    res.redirect('/admin/query')

}

exports.querydelete= async (req, res) => {
    const id = req.params.id
    await querydb.findByIdAndDelete(id)
    res.redirect('/admin/query')
}

exports.querysearch= async (req, res) => {
    const { search } = req.body
    const record = await querydb.find({ status: search })
    res.render('admin/query.ejs', { record })
}

