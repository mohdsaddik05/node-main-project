const router = require('express').Router() //module
const cbanner=require('../../Controller/Admincontroller/Bannercontroller')
const cservices= require('../../Controller/Admincontroller/Servicescontroller')
const cquery= require('../../Controller/Admincontroller/Querycontroller')
const ctesti= require('../../Controller/Admincontroller/Testinomialcontroller')
const caddress= require('../../Controller/Admincontroller/Addresscontroller')
const ccompany= require('../../Controller/Admincontroller/Companycontroller')
const cuser= require('../../Controller/Admincontroller/Usercontroller')
const logindb = require('../../models/admin/logindb')
const multer = require('multer')
const nodemailer = require('nodemailer')



//-----------session function----------//
function handlelogin(req, res, next) {
    if (req.session.isAuth) {
        next()
    } else {
        res.redirect('/admin')
    }
}
//--------------------------------------


//--------------Multer setup  ---------------
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/upload')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + file.originalname)
    }
})


const upload = multer({
    storage: storage,
    limits: { fileSize: 1024 * 1024 * 4 }
})

// --------- Multer setup end ------------//

//-------- admin Login-----// 
router.get('/', (req, res) =>{
    res.render('admin/login.ejs')
})

router.get('/dashboard', handlelogin, (req, res) => {
    res.render('admin/dashboard.ejs')
})

router.post('/adminrecord', async (req, res) => {
    const { us, pass } = req.body
    const record = await logindb.findOne({ username: us })
    //console.log(record)
    if (record !== null) {
        if (record.password == pass) {
            req.session.isAuth = true
            res.redirect('/admin/dashboard')
        } else {
            res.redirect('/admin/')
        }
    } else {
        res.redirect('/admin/')
    }

})

/*router.post('/adminrecord',async(req,res)=>{
    const{us,pass} = req.body
    const record = new logindb({username:us,password:pass})
    await record.save()
     res.redirect('/admin/')
   }) */

router.get('/logout', (req, res) => {
    req.session.destroy()
    res.redirect('/admin/')
})

//---------- Banner management start ------------//

router.get('/banner', handlelogin,cbanner.bannershow )

router.get('/banneradd', handlelogin,cbanner.banneradd)

router.post('/badd',handlelogin, upload.single('img'), cbanner.banneraddinsert)


router.get('/bannerupdate/:abc', handlelogin,cbanner.bannerupdateshow)

router.post('/bupdate/:def', handlelogin,upload.single('img'), cbanner.bannerupdateinsert)

router.get('/bannerdelete/:abc', handlelogin,cbanner.bannerdelete)

//------------- Banner management end --------------//



//------------services Management-------------//

router.get('/service', handlelogin,cservices.servicesshow)

router.get('/serviceadd', handlelogin,cservices.servicesadd)

router.post('/serviceinsert',handlelogin, upload.single('img'),cservices.servicesinsert)

router.get('/delete/:abc', handlelogin, cservices.servicesdelete)

router.get('/serviceupdate/:xyz',handlelogin, cservices.servicesupdate)

//----------- Query Management---------------------//

router.get('/query', handlelogin, cquery.queryshow)

router.post('/queryform',cquery.querypost)

router.get('/replyform/:id', cquery.replyshow)

router.post('/replyto/:id', upload.single('attachment'),cquery.replysend)

router.get('/querydelete/:id', cquery.querydelete)

router.post('/querysearch', cquery.querysearch)


//-------------- Testinominals -------------//

router.get('/testi', handlelogin, ctesti.testishow)

router.get('/testidelete/:id',handlelogin, ctesti.testidelete)

router.get('/testiupdate/:id',handlelogin,ctesti.testiupdate)


//------------------ Address Management--------------//

router.get('/address', handlelogin, caddress.addressshow)

router.get('/addressinsert', handlelogin,caddress.addressinsertshow)

router.post('/addressadd', caddress.addressinsert)

router.get('/addressupdate/:id', handlelogin,caddress.addressupdateshow)

router.post('/addressrecord/:id',caddress.addressupdate)

router.get('/addressdelete/:id',caddress.addressdelete)


//------------------ Company Management--------------//

router.get('/company', handlelogin, ccompany.companyshow)

router.get('/companyinsert', handlelogin,ccompany.companyinsertshow)

router.post('/companyadd', upload.single('img'), ccompany.companyadd)

router.get('/companyupdate/:id', handlelogin,ccompany.companyupdateshow)

router.post('/companyrecord/:id', upload.single('img'), ccompany.companyupdate)

router.get('/companydelete/:id',ccompany.companydelete)

//--------- Users Management ------

router.get('/users', handlelogin, cuser.usershow)

router.get('/userstatusupdate/:id',handlelogin, cuser.userupdateshow)

router.get('/userstatusrole/:id', handlelogin,cuser.userstatus)

router.get('/userdelete/:id',handlelogin,cuser.userdelete)

module.exports = router