const router = require('express').Router() //module
const bannerdb = require('../../models/admin/bannerdb')
const servicedb = require('../../models/admin/servicedb')
const multer = require('multer')
const testidb = require('../../models/admin/testidb')
const addressdb = require('../../models/admin/addressdb')
const companydb = require('../../models/admin/companydb')
const regdb = require('../../models/admin/regdb')


let sess = null

function handlerole (req, res, next ) {
  if (sess.userrole == 'public') {
    next()
  } else {
  /*
      if(sess!=null){

      res.render('testiidrole.ejs',{ username: sess.username})
    }else{
      res.render('testiidrole.ejs',{ username: 'hello'})
    }}
    
    */
    
    res.send("You don't have right to see this page.")
  }
}



function handlelogin(req, res, next) {
  if (req.session.isAuth) {
    next()
  } else {
    res.redirect('/login')
  }
}

//--------------Multer setup  ---------------
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './public/upload')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname)
  }
})


const upload = multer({
  storage: storage,
  limits: { fileSize: 1024 * 1024 * 4 }
})

// --------- Multer setup end ------------


router.get('/', handlelogin, async (req, res) => {
  const banner = await bannerdb.findOne()
  const service = await servicedb.find({ status: 'publish' })
  const testi = await testidb.find({ status: 'publish' })
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    res.render('index.ejs', { banner, service, testi, addressview, companyview, username: sess.username })
  } else {
    res.redirect('/login', { banner, service, testi, addressview, companyview, username: 'hello' })

  }
})

router.get('/moredetail', async (req, res) => {
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  const record = await bannerdb.findOne()
  if (sess !== null) {
  res.render('moredetail.ejs', { record, addressview, companyview, username: sess.username})
  }else{
    res.render('moredetail.ejs', { record, addressview, companyview, username: 'hello'})

  }
})

router.get('/moredetailcontain/:xyz', async (req, res) => {
  const id = req.params.xyz
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  const record = await servicedb.findById(id)
  if(sess!==null){
    res.render('moredetailcontain.ejs', { record, addressview, companyview, username: sess.username })
  }else{
    res.render('moredetailcontain.ejs', { record, addressview, companyview, username: 'hello' })
  }
})


//------------ testinominal start--------
router.get('/testiform', handlelogin, handlerole, async (req, res) => {
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  const record = await testidb.find()
  if (sess !== null) {
    res.render('testiform.ejs', { record, addressview, companyview, username: sess.username })
  } else {
    res.render('testiform.ejs', { record, addressview, companyview, username: 'hello' })
  }

})

router.post('/testirecord', upload.single('img'), async (req, res) => {
  const { quotes, cname } = req.body
  if (req.file) {
    const filename = req.file.filename
    const record = new testidb({ image: filename, quotes: quotes, cname: cname, postedDate: new Date(), status: 'unpublish' })
    await record.save()
  } else {
    const record = new testidb({ quotes: quotes, cname: cname, postedDate: new Date(), status: 'unpublish' })
  }

  res.redirect('/')
  //console.log(record)
})

router.get('/reg', async (req, res) => {
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    res.render('reg.ejs', { message:'',addressview, companyview, username: sess.username })
  } else {
    res.render('reg.ejs', {message:'', addressview, companyview, username: 'hello' })
  }
})

router.post('/regrecord', async (req, res) => {
  const { us, pass } = req.body
  const usercheck = await regdb.findOne({ username: us })
  if (usercheck == null) {
    const record = new regdb({ username: us, password: pass, registerDate: new Date() })
    await record.save()

  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    res.render('reg.ejs', {message:'Registration successfully', addressview, companyview, username: sess.username })
  } else {
    res.render('reg.ejs', {message:'Registration successfully', addressview, companyview, username: 'hello' })
  }


    //res.redirect('/login')

    
  }  else {
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    if (sess !== null) {
      res.render('reg.ejs', {message:'', addressview, companyview, username: sess.username })
    } else {
      res.render('reg.ejs', { message:'Already taken account',addressview, companyview, username: 'hello' })
    }
  }
})

router.get('/login', async (req, res) => {
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    res.render('login.ejs', {message:'', addressview, companyview, username: sess.username })
  } else {
    res.render('login.ejs', {message:'', addressview, companyview, username: 'hello' })
  }
  
})

router.post('/loginrecord', async (req, res) => {
  const { us, pass } = req.body
  const record = await regdb.findOne({ username: us })
  if (record !== null) {
    if (record.password == pass) {
      if (record.status == 'active') {
        req.session.isAuth = true
        sess = req.session
        sess.username = us
        sess.userrole = record.role
        res.redirect('/')
      } 
      else {
        const addressview = await addressdb.findOne()
        const companyview = await companydb.findOne()
        if (sess !== null) {
          res.render('login.ejs', {message:'', addressview, companyview, username: sess.username })
        } else {
          res.render('login.ejs', { message:'Your account is suspended. Please cordinate with your admin.',addressview, companyview, username: 'hello' })
        }
      }
      
      /*else {
        res.send("Your account is suspended. Please cordinate with your admin.")
      }*/

    } else {
      const addressview = await addressdb.findOne()
      const companyview = await companydb.findOne()
      if (sess !== null) {
        res.render('login.ejs', {message:'Wrong Credentails', addressview, companyview, username: sess.username })
      } else {
        res.render('login.ejs', { message:'Wrong Credentails',addressview, companyview, username: 'hello' })
      }
    }
  } else {
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    if (sess !== null) {
      res.render('login.ejs', {message:'Wrong Credentails', addressview, companyview, username: sess.username })
    } else {
      res.render('login.ejs', { message:'Wrong Credentails',addressview, companyview, username: 'hello' })
    }
  }
}
)



router.get('/logout',(req, res) => {
  req.session.destroy()
  sess = null
  res.redirect('/login')
})

router.get('/profile', handlelogin, async (req, res) => {
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    const record = await regdb.findOne({ username: sess.username })
    res.render('profile.ejs', {message:'', record, addressview, companyview, username: sess.username })
  } else {
    res.render('profile.ejs', { message:'',addressview, companyview, username: 'hello' })
  }
})

router.post('/profilerecord/:id', upload.single('img'), async (req, res) => {
  const id = req.params.id
  const { fname, lname, email } = req.body
    
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()

  let imagename = null
  if (req.file) {
    imagename = req.file.filename
    await regdb.findByIdAndUpdate(id, { firstname: fname, lastname: lname, email: email, img: imagename })
  } else {
    await regdb.findByIdAndUpdate(id, { firstname: fname, lastname: lname, email: email })
  }

  if (sess !== null) {
    const record = await regdb.findOne({ username: sess.username })
    res.render('profile.ejs', {message:'Successfully Updated.', record, addressview, companyview, username: sess.username })
  } else {
    res.render('profile.ejs', {message:'Successfully Updated.', addressview, companyview, username: 'hello' })
  }
})


router.get('/password', handlelogin, async (req, res) => {

  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    const record = await regdb.findOne({ username: sess.username })
    res.render('passwordchange.ejs', {message:'',message1:'', record, addressview, companyview, username: sess.username })
  } else {
    res.render('passwordchange.ejs', {message:'',message1:'', record, addressview, companyview, username: 'hello' })
  }
})

router.post('/passwordchangerecord/:id', async (req, res) => {
  const id = req.params.id
  const { cp, np } = req.body
  const record = await regdb.findById(id)
  if (record.password == cp) {
    await regdb.findByIdAndUpdate(id, { password: np })
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    if (sess !== null) {
      const record = await regdb.findOne({ username: sess.username })
      res.render('passwordchange.ejs', {message1:'Your Password is change successfully ',message:'', record, addressview, companyview, username: sess.username })
    } else {
      res.render('passwordchange.ejs', { message1:'Your Password is change successfully',message:'',record, addressview, companyview, username: 'hello' })
    }
  } else {
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    if (sess !== null) {
      const record = await regdb.findOne({ username: sess.username })
      res.render('passwordchange.ejs', {message:'Cuurent Password is not matched',message1:'', record, addressview, companyview, username: sess.username })
    } else {
      res.render('passwordchange.ejs', { message:'Cuurent Password is not matched',message1:'',record, addressview, companyview, username: 'hello' })
    }
  }
})

router.get('/forgotpassword', async (req, res) => {
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    res.render('forgotpassword.ejs', { addressview, companyview, username: sess.username })
  } else {
    res.render('forgotpassword.ejs', { addressview, companyview, username: 'hello' })
  }
})

router.post('/fpasswordrecord', async (req, res) => {
  const { username } = req.body
  const record = await regdb.findOne({ username: username })

  if (record !== null) {
    //email link attachment
  } else {
    res.send('Username not found.')
  }
})


router.get('/forgotlink', async (req, res) => {
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    res.render('forgotlink.ejs', { addressview, companyview, username: sess.username })
  } else {
    res.render('forgotlink.ejs', { addressview, companyview, username: 'hello' })
  }
})


module.exports = router