const mongoose = require('mongoose')


const regSchema = mongoose.Schema({
    username: String,
    password: String,
    firstname: String,
    lastname: String,
    email: String,
    img: { type: String, default: 'profileimg.png' },
    status: { type: String, default: 'active' },
    role: { type: String, default: 'public' },
    registerDate:String
})





module.exports = mongoose.model('reg', regSchema)