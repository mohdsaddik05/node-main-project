const mongoose = require('mongoose')


const companySchema=mongoose.Schema({
    image:String,
    cname:String
})





module.exports = mongoose.model('company',companySchema)